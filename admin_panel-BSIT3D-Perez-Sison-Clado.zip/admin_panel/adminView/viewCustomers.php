<div>
  <h2>All Customers</h2>  <!-- Title for the section showing all customers -->

  <!-- Table for displaying customer details -->
  <table class="table">
    <thead>
      <tr>
        <th class="text-center">S.N.</th>  <!-- Serial Number column -->
        <th class="text-center">Username</th>  <!-- Customer's full name -->
        <th class="text-center">Email</th>  <!-- Customer's email address -->
        <th class="text-center">Contact Number</th>  <!-- Customer's contact number -->
        <th class="text-center">Joining Date</th>  <!-- Customer's registration date -->
      </tr>
    </thead>
    <?php
      // Include database connection
      include_once "../config/dbconnect.php";
      
      // SQL query to fetch non-admin users (customers)
      $sql="SELECT * from users where isAdmin=0";
      $result=$conn-> query($sql);
      $count=1;  // Counter for serial number
      
      // Check if there are any customers
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {  // Loop through each row of result
    ?>
    <tr>
      <td><?=$count?></td>  <!-- Serial number -->
      <td><?=$row["first_name"]?> <?=$row["last_name"]?></td>  <!-- Full name of the customer -->
      <td><?=$row["email"]?></td>  <!-- Customer's email address -->
      <td><?=$row["contact_no"]?></td>  <!-- Customer's contact number -->
      <td><?=$row["registered_at"]?></td>  <!-- Customer's registration date -->
    </tr>
    <?php
            $count=$count+1;  // Increment serial number
        }
      }
    ?>
  </table>
</div>

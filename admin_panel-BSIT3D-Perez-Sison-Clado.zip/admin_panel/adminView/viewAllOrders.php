<div id="ordersBtn">
  <h2>Order Details</h2>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>O.N.</th>  <!-- Order Number -->
        <th>Customer</th>  <!-- Customer Name -->
        <th>Contact</th>  <!-- Customer Contact -->
        <th>OrderDate</th>  <!-- Date of Order -->
        <th>Payment Method</th>  <!-- Payment Method Used -->
        <th>Order Status</th>  <!-- Current Order Status -->
        <th>Payment Status</th>  <!-- Payment Status -->
        <th>More Details</th>  <!-- Link to view more details about the order -->
     </tr>
    </thead>
     <?php
      // Include database connection file
      include_once "../config/dbconnect.php";
      
      // Query to fetch all orders from the database
      $sql="SELECT * from orders";
      $result=$conn-> query($sql);
      
      if ($result-> num_rows > 0){  // Check if there are any orders
        while ($row=$result-> fetch_assoc()) {  // Loop through each order
    ?>
       <tr>
          <!-- Display order details in table -->
          <td><?=$row["order_id"]?></td>  <!-- Order ID -->
          <td><?=$row["delivered_to"]?></td>  <!-- Customer name -->
          <td><?=$row["phone_no"]?></td>  <!-- Customer contact number -->
          <td><?=$row["order_date"]?></td>  <!-- Date the order was placed -->
          <td><?=$row["pay_method"]?></td>  <!-- Payment method used -->
          
          <?php 
                // If the order status is 0 (Pending)
                if($row["order_status"]==0){
            ?>
                <!-- Button to mark order as 'Pending' -->
                <td><button class="btn btn-danger" onclick="ChangeOrderStatus('<?=$row['order_id']?>')">Pending</button></td>
            <?php
                }else{
            ?>
                <!-- Button to mark order as 'Delivered' -->
                <td><button class="btn btn-success" onclick="ChangeOrderStatus('<?=$row['order_id']?>')">Delivered</button></td>
            <?php
                }
                // Check payment status (0: Unpaid, 1: Paid)
                if($row["pay_status"]==0){
            ?>
                <!-- Button to mark payment as 'Unpaid' -->
                <td><button class="btn btn-danger" onclick="ChangePay('<?=$row['order_id']?>')">Unpaid</button></td>
            <?php
                }else if($row["pay_status"]==1){
            ?>
                <!-- Button to mark payment as 'Paid' -->
                <td><button class="btn btn-success" onclick="ChangePay('<?=$row['order_id']?>')">Paid</button></td>
            <?php
                }
            ?>
              
        <!-- Link to view order details in a modal -->
        <td><a class="btn btn-primary openPopup" data-href="./adminView/viewEachOrder.php?orderID=<?=$row['order_id']?>" href="javascript:void(0);">View</a></td>
        </tr>
    <?php
        }
      }
    ?>
     
  </table>
</div>

<!-- Modal for viewing order details -->
<div class="modal fade" id="viewModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Order Details</h4>  <!-- Title of the modal -->
          <button type="button" class="close" data-dismiss="modal">&times;</button>  <!-- Close button for the modal -->
        </div>
        <div class="order-view-modal modal-body">
          <!-- Order details will be loaded here dynamically -->
        </div>
      </div>
    </div>
</div>

<script>
    // jQuery to load order details into the modal when the "View" button is clicked
    $(document).ready(function(){
      $('.openPopup').on('click',function(){
        var dataURL = $(this).attr('data-href');  // Get the data-href attribute (URL to fetch order details)
    
        // Load the order details into the modal body and show the modal
        $('.order-view-modal').load(dataURL,function(){
          $('#viewModal').modal({show:true});
        });
      });
    });
 </script>

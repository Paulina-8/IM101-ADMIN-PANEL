<div>
  <h2>Product Sizes Item</h2>
  <table class="table">
    <thead>
      <tr>
        <th class="text-center">S.N.</th>
        <th class="text-center">Product Name</th>
        <th class="text-center">Size</th>
        <th class="text-center">Stock Quantity</th>
        <th class="text-center" colspan="2">Action</th>
      </tr>
    </thead>
    <?php
      include_once "../config/dbconnect.php";  // Database connection
      // Query to fetch product size variations
      $sql = "SELECT * FROM product_size_variation v, product p, sizes s 
              WHERE p.product_id = v.product_id AND v.size_id = s.size_id";
      $result = $conn-> query($sql);  // Execute the query
      $count = 1;  // Initialize the serial number
      if ($result-> num_rows > 0) {  // Check if there are any results
        while ($row = $result-> fetch_assoc()) {  // Loop through each product size variation
    ?>
    <tr>
      <td><?=$count?></td>  <!-- Display serial number -->
      <td><?=$row["product_name"]?></td>  <!-- Display product name -->
      <td><?=$row["size_name"]?></td>  <!-- Display size name -->
      <td><?=$row["quantity_in_stock"]?></td>  <!-- Display stock quantity -->
      <td><button class="btn btn-primary" style="height:40px" onclick="variationEditForm('<?=$row['variation_id']?>')">Edit</button></td>  <!-- Edit button -->
      <td><button class="btn btn-danger" style="height:40px" onclick="variationDelete('<?=$row['variation_id']?>')">Delete</button></td>  <!-- Delete button -->
    </tr>
    <?php
        $count = $count + 1;  // Increment serial number
        }
      }
    ?>
  </table>

  <!-- Add Size Variation Button -->
  <button type="button" class="btn btn-secondary" style="height:40px" data-toggle="modal" data-target="#myModal">
    Add Size Variation
  </button>

  <!-- Modal to add a new size variation -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">New Product Size Variation</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form enctype='multipart/form-data' action="./controller/addVariationController.php" method="POST">
            <!-- Select Product -->
            <div class="form-group">
              <label>Product:</label>
              <select name="product">
                <option disabled selected>Select product</option>
                <?php
                  // Query to fetch products
                  $sql = "SELECT * FROM product";
                  $result = $conn-> query($sql);
                  if ($result-> num_rows > 0) {
                    while ($row = $result-> fetch_assoc()) {
                      echo "<option value='".$row['product_id']."'>".$row['product_name']."</option>";
                    }
                  }
                ?>
              </select>
            </div>
            <!-- Select Size -->
            <div class="form-group">
              <label>Size:</label>
              <select name="size">
                <option disabled selected>Select size</option>
                <?php
                  // Query to fetch sizes
                  $sql = "SELECT * FROM sizes";
                  $result = $conn-> query($sql);
                  if ($result-> num_rows > 0) {
                    while ($row = $result-> fetch_assoc()) {
                      echo "<option value='".$row['size_id']."'>".$row['size_name']."</option>";
                    }
                  }
                ?>
              </select>
            </div>
            <!-- Stock Quantity -->
            <div class="form-group">
              <label for="qty">Stock Quantity:</label>
              <input type="number" class="form-control" name="qty" required>
            </div>
            <!-- Submit Button -->
            <div class="form-group">
              <button type="submit" class="btn btn-secondary" name="upload" style="height:40px">Add Variation</button>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>

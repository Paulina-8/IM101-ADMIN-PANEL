<div class="container p-5">

<h4>Edit Product Detail</h4>
<?php
    include_once "../config/dbconnect.php";  // Includes the database connection file
	$ID = $_POST['record'];  // Gets the product ID from the form submission
	$qry = mysqli_query($conn, "SELECT * FROM product WHERE product_id='$ID'");  // Query to fetch the product details by ID
	$numberOfRow = mysqli_num_rows($qry);  // Check how many rows are returned

	if($numberOfRow > 0){  // If the product exists
		while($row1 = mysqli_fetch_array($qry)){  // Loop through the fetched product data
      $catID = $row1["category_id"];  // Store the current category ID
?>
<form id="update-Items" onsubmit="updateItems()" enctype='multipart/form-data'>  // Form to update the product details
	<div class="form-group">
      <input type="text" class="form-control" id="product_id" value="<?=$row1['product_id']?>" hidden>  // Hidden input for product ID
    </div>
    <div class="form-group">
      <label for="name">Product Name:</label>
      <input type="text" class="form-control" id="p_name" value="<?=$row1['product_name']?>">  // Input for product name
    </div>
    <div class="form-group">
      <label for="desc">Product Description:</label>
      <input type="text" class="form-control" id="p_desc" value="<?=$row1['product_desc']?>">  // Input for product description
    </div>
    <div class="form-group">
      <label for="price">Unit Price:</label>
      <input type="number" class="form-control" id="p_price" value="<?=$row1['price']?>">  // Input for product price
    </div>
    <div class="form-group">
      <label>Category:</label>
      <select id="category">  // Dropdown for selecting the product category
        <?php
          $sql = "SELECT * from category WHERE category_id='$catID'";  // Fetch the current category
          $result = $conn-> query($sql);
          if ($result-> num_rows > 0){
            while($row = $result-> fetch_assoc()){
              echo "<option value='". $row['category_id'] ."'>" .$row['category_name'] ."</option>";  // Display current category in the dropdown
            }
          }
        ?>
        <?php
          $sql = "SELECT * from category WHERE category_id!='$catID'";  // Fetch all categories except the current one
          $result = $conn-> query($sql);
          if ($result-> num_rows > 0){
            while($row = $result-> fetch_assoc()){
              echo "<option value='". $row['category_id'] ."'>" .$row['category_name'] ."</option>";  // Display other categories in the dropdown
            }
          }
        ?>
      </select>
    </div>
      <div class="form-group">
         <img width='200px' height='150px' src='<?=$row1["product_image"]?>'>  // Display current product image
         <div>
            <label for="file">Choose Image:</label>
            <input type="text" id="existingImage" class="form-control" value="<?=$row1['product_image']?>" hidden>  // Hidden input for existing image URL
            <input type="file" id="newImage" value="">  // Input to upload a new image
         </div>
    </div>
    <div class="form-group">
      <button type="submit" style="height:40px" class="btn btn-primary">Update Item</button>  // Submit button to update the product
    </div>
    <?php
    		}
    	}
    ?>
  </form>

</div>

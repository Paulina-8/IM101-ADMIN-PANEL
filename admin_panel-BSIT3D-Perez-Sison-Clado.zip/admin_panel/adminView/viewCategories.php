<div>
  <h3>Category Items</h3>  <!-- Title for the Category Items section -->
  
  <!-- Table for displaying existing categories -->
  <table class="table">
    <thead>
      <tr>
        <th class="text-center">S.N.</th>  <!-- Serial Number -->
        <th class="text-center">Category Name</th>  <!-- Category Name -->
        <th class="text-center" colspan="2">Action</th>  <!-- Action Buttons: Delete -->
      </tr>
    </thead>
    <?php
      // Include database connection
      include_once "../config/dbconnect.php";
      
      // SQL query to fetch category details
      $sql="SELECT * from category";
      $result=$conn-> query($sql);
      $count=1;  // Counter for serial number
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {  // Loop through the result set
    ?>
    <tr>
      <td><?=$count?></td>  <!-- Serial number -->
      <td><?=$row["category_name"]?></td>  <!-- Category Name -->
   
      <!-- Delete Button: Calls categoryDelete() function with category ID -->
      <td><button class="btn btn-danger" style="height:40px" onclick="categoryDelete('<?=$row['category_id']?>')">Delete</button></td>
    </tr>
    <?php
            $count=$count+1;  // Increment serial number
          }
        }
      ?>
  </table>

  <!-- Add Category Button to open modal -->
  <button type="button" class="btn btn-secondary" style="height:40px" data-toggle="modal" data-target="#myModal">
    Add Category
  </button>

  <!-- Modal for adding a new category -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">New Category Item</h4>  <!-- Modal Title -->
          <button type="button" class="close" data-dismiss="modal">&times;</button>  <!-- Close Button -->
        </div>
        <div class="modal-body">
          <!-- Form for adding a new category -->
          <form enctype='multipart/form-data' action="./controller/addCatController.php" method="POST">
            <div class="form-group">
              <label for="c_name">Category Name:</label>
              <input type="text" class="form-control" name="c_name" required>  <!-- Category Name Input -->
            </div>
            <div class="form-group">
              <!-- Submit Button for adding the category -->
              <button type="submit" class="btn btn-secondary" name="upload" style="height:40px">Add Category</button>
            </div>
          </form>

        </div>
        <div class="modal-footer">
          <!-- Close Button for modal -->
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px">Close</button>
        </div>
      </div>
      
    </div>
  </div>

</div>

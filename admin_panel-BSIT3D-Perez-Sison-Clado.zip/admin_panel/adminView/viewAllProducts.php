<div>
  <h2>Product Items</h2>
  <table class="table">
    <thead>
      <tr>
        <th class="text-center">S.N.</th>  <!-- Serial Number -->
        <th class="text-center">Product Image</th>  <!-- Product Image -->
        <th class="text-center">Product Name</th>  <!-- Product Name -->
        <th class="text-center">Product Description</th>  <!-- Product Description -->
        <th class="text-center">Category Name</th>  <!-- Category Name -->
        <th class="text-center">Unit Price</th>  <!-- Unit Price -->
        <th class="text-center" colspan="2">Action</th>  <!-- Action Buttons: Edit and Delete -->
      </tr>
    </thead>
    <?php
      // Include database connection
      include_once "../config/dbconnect.php";
      
      // SQL query to fetch product and category details
      $sql="SELECT * from product, category WHERE product.category_id=category.category_id";
      $result=$conn-> query($sql);
      $count=1;  // Counter for serial number
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {  // Loop through the result set
    ?>
    <tr>
      <td><?=$count?></td>  <!-- Serial number -->
      <td><img height='100px' src='<?=$row["product_image"]?>'></td>  <!-- Product Image -->
      <td><?=$row["product_name"]?></td>  <!-- Product Name -->
      <td><?=$row["product_desc"]?></td>  <!-- Product Description -->
      <td><?=$row["category_name"]?></td>  <!-- Category Name -->
      <td><?=$row["price"]?></td>  <!-- Product Price -->
      <td>
        <!-- Edit Button: Calls itemEditForm() function with product ID -->
        <button class="btn btn-primary" style="height:40px" onclick="itemEditForm('<?=$row['product_id']?>')">Edit</button>
      </td>
      <td>
        <!-- Delete Button: Calls itemDelete() function with product ID -->
        <button class="btn btn-danger" style="height:40px" onclick="itemDelete('<?=$row['product_id']?>')">Delete</button>
      </td>
    </tr>
    <?php
            $count=$count+1;  // Increment serial number
          }
        }
      ?>
  </table>

  <!-- Add Product Button to open modal -->
  <button type="button" class="btn btn-secondary " style="height:40px" data-toggle="modal" data-target="#myModal">
    Add Product
  </button>

  <!-- Modal for adding a new product -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">New Product Item</h4>  <!-- Modal Title -->
          <button type="button" class="close" data-dismiss="modal">&times;</button>  <!-- Close Button -->
        </div>
        <div class="modal-body">
          <!-- Form for adding a new product -->
          <form  enctype='multipart/form-data' onsubmit="addItems()" method="POST">
            <div class="form-group">
              <label for="name">Product Name:</label>
              <input type="text" class="form-control" id="p_name" required>  <!-- Product Name Input -->
            </div>
            <div class="form-group">
              <label for="price">Price:</label>
              <input type="number" class="form-control" id="p_price" required>  <!-- Product Price Input -->
            </div>
            <div class="form-group">
              <label for="qty">Description:</label>
              <input type="text" class="form-control" id="p_desc" required>  <!-- Product Description Input -->
            </div>
            <div class="form-group">
              <label>Category:</label>
              <!-- Category Selection Dropdown -->
              <select id="category" >
                <option disabled selected>Select category</option>
                <?php
                  // Fetch available categories from the database
                  $sql="SELECT * from category";
                  $result = $conn-> query($sql);
                  if ($result-> num_rows > 0){
                    while($row = $result-> fetch_assoc()){
                      echo"<option value='".$row['category_id']."'>".$row['category_name'] ."</option>";
                    }
                  }
                ?>
              </select>
            </div>
            <div class="form-group">
                <label for="file">Choose Image:</label>
                <input type="file" class="form-control-file" id="file">  <!-- Product Image Input -->
            </div>
            <div class="form-group">
              <!-- Submit Button for adding the product -->
              <button type="submit" class="btn btn-secondary" id="upload" style="height:40px">Add Item</button>
            </div>
          </form>

        </div>
        <div class="modal-footer">
          <!-- Close Button for modal -->
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px">Close</button>
        </div>
      </div>
      
    </div>
  </div>

</div>

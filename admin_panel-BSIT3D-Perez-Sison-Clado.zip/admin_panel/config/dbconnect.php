<?php

// Database connection parameters
$server = "localhost";   // Server name (localhost for local development)
$user = "root";          // Database username (default 'root' for MySQL)
$password = "";          // Database password (empty by default for local setups)
$db = "swiss_collection"; // Name of the database to connect to

// Establish a connection to the MySQL database
$conn = mysqli_connect($server, $user, $password, $db);

// Check if the connection was successful
if(!$conn) {
    die("Connection Failed:".mysqli_connect_error());  // If the connection fails, display an error message
}

?>

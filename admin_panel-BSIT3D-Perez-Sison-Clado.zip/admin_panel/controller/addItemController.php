<?php
    include_once "../config/dbconnect.php";  // Includes the database connection file
    
    if(isset($_POST['upload']))  // Checks if the form is submitted with 'upload' as the button name
    {
       
        $ProductName = $_POST['p_name'];  // Gets the product name from the form
        $desc = $_POST['p_desc'];  // Gets the product description from the form
        $price = $_POST['p_price'];  // Gets the product price from the form
        $category = $_POST['category'];  // Gets the category from the form
       
        // File upload processing
        $name = $_FILES['file']['name'];  // Gets the uploaded file's name
        $temp = $_FILES['file']['tmp_name'];  // Gets the temporary location of the uploaded file
    
        $location = "./uploads/";  // Directory where the image will be saved
        $image = $location . $name;  // Complete path of the uploaded image
        
        $target_dir = "../uploads/";  // Target directory for the image on the server
        $finalImage = $target_dir . $name;  // Final path where the image will be moved

        move_uploaded_file($temp, $finalImage);  // Moves the uploaded file to the target directory

         // Insert product data into the database
         $insert = mysqli_query($conn, "INSERT INTO product
         (product_name, product_image, price, product_desc, category_id) 
         VALUES ('$ProductName', '$image', $price, '$desc', '$category')");
 
         if(!$insert)  // Checks if the insert query failed
         {
             echo mysqli_error($conn);  // Displays the error message if the query fails
         }
         else
         {
             echo "Records added successfully.";  // Confirms success if the query succeeds
         }
     
    }
        
?>
<!-- PEREZ-SISON-CLADO -->
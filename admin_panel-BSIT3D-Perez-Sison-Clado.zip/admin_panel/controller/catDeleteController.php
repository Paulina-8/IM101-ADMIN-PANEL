<?php

    include_once "../config/dbconnect.php";  // Includes the database connection file
    
    $c_id = $_POST['record'];  // Gets the category ID from the form to be deleted
    $query = "DELETE FROM category where category_id='$c_id'";  // SQL query to delete the category by ID

    $data = mysqli_query($conn, $query);  // Executes the SQL query to delete the category

    if($data) {  // Checks if the deletion was successful
        echo "Category Item Deleted";  // Confirms the category was deleted
    }
    else {  // If the deletion failed
        echo "Not able to delete";  // Displays an error message
    }
    
?>
<!-- PEREZ-SISON-CLADO -->
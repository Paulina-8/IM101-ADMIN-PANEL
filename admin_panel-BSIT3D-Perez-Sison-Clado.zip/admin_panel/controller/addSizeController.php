<?php
    include_once "../config/dbconnect.php";  // Includes the database connection file
    
    if(isset($_POST['upload']))  // Checks if the form is submitted with 'upload' as the button name
    {
       
        $size = $_POST['size'];  // Gets the size value from the form
       
         // Insert the size data into the 'sizes' table in the database
         $insert = mysqli_query($conn,"INSERT INTO sizes
         (size_name)   VALUES ('$size')");
 
         if(!$insert)  // Checks if the insert query failed
         {
             echo mysqli_error($conn);  // Displays the error message if the query fails
             header("Location: ../index.php?size=error");  // Redirects with an error message if insert fails
         }
         else
         {
             echo "Records added successfully.";  // Confirms success if the query succeeds
             header("Location: ../index.php?size=success");  // Redirects with a success message
         }
     
    }
        
?>
<!-- PEREZ-SISON-CLADO -->
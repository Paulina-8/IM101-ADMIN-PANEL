<?php
    include_once "../config/dbconnect.php";  // Includes the database connection file
    
    if(isset($_POST['upload']))  // Checks if the form is submitted with 'upload' as the button name
    {
       
        $product = $_POST['product'];  // Gets the selected product ID from the form
        $size = $_POST['size'];  // Gets the selected size ID from the form
        $qty = $_POST['qty'];  // Gets the quantity in stock from the form

         // Insert the product, size, and quantity data into the 'product_size_variation' table
         $insert = mysqli_query($conn,"INSERT INTO product_size_variation
         (product_id, size_id, quantity_in_stock) VALUES ('$product', '$size', '$qty')");
 
         if(!$insert)  // Checks if the insert query failed
         {
             echo mysqli_error($conn);  // Displays the error message if the query fails
             header("Location: ../index.php?variation=error");  // Redirects with an error message if insert fails
         }
         else
         {
             echo "Records added successfully.";  // Confirms success if the query succeeds
             header("Location: ../index.php?variation=success");  // Redirects with a success message
         }
     
    }
        
?>
<!-- PEREZ-SISON-CLADO -->
<?php
    include_once "../config/dbconnect.php";  // Includes the database connection file
    
    if(isset($_POST['upload']))  // Checks if the form is submitted with 'upload' as the button name
    {
       
        $catname = $_POST['c_name'];  // Gets the category name input from the form
       
         $insert = mysqli_query($conn,"INSERT INTO category
         (category_name) 
         VALUES ('$catname')");  // Executes the SQL query to insert the category into the database

         if(!$insert)  // Checks if the query was unsuccessful
         {
             echo mysqli_error($conn);  // Displays the error if the query fails
             header("Location: ../index.php?category=error");  // Redirects to index page with error message
         }
         else
         {
             echo "Records added successfully.";  // Confirms success
             header("Location: ../index.php?category=success");  // Redirects to index page with success message
         }
     
    }
        
?>
<!-- PEREZ-SISON-CLADO -->
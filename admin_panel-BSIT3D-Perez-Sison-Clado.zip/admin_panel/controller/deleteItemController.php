<?php

    include_once "../config/dbconnect.php";  // Includes the database connection file
    
    $p_id = $_POST['record'];  // Gets the product ID from the form (to be deleted)
    $query = "DELETE FROM product where product_id='$p_id'";  // SQL query to delete the product by its ID

    $data = mysqli_query($conn, $query);  // Executes the delete query on the database

    if($data) {  // Checks if the query executed successfully
        echo "Product Item Deleted";  // If successful, display confirmation message
    }
    else {  // If the query failed
        echo "Not able to delete";  // Display an error message
    }
    
?>
<!-- PEREZ-SISON-CLADO -->